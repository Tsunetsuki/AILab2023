#Anything in this file, followed by a period (and an upper-case word), does NOT indicate an end-of-sentence marker.

#common exceptions
# Dr
ഡോ
# Mr
ശ്രീ

#others


#phonetics
# A
എ
# B
ബി
# C
സി
# D
ഡി
# E
ഇ
# F
എഫ്
# G
ജി
# H
എച്ച്
# I
ഐ
# J
ജെ
# K
കെ
# L
എൽ
# M
എം
# N
എൻ
# O
ഒ
# P
പി 
# Q
ക്യൂ
# R
ആർ
# S
എസ്
# T
ടി
# U
യു
# V
വി
# W
ഡബ്ല്യു
# X
എക്സ്
# Y
വൈ
# Z
സെഡ്

#consonants

